let t="http://localhost:2606";export{t as b};
