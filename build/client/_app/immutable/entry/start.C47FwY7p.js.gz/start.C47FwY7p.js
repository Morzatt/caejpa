import{a as t}from"../chunks/entry.D-2JlSkr.js";export{t as start};
